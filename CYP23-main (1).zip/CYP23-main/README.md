# CYP23
Commons Yummifcation Project:
In order to run this project, download all of the files and run the home.html file in a live server such as node.js.
